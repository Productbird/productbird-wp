<?php

namespace Productbird\Frontend;

/**
 * Handles public-facing functionality.
 */
class Frontend
{
    /**
     * Bootstraps frontend hooks.
     */
    public function init(): void
    {
        // Register frontend hooks here.
    }
}